import tkinter as tk
from tkinter import messagebox as msb
import time as t
from concurrent.futures import ThreadPoolExecutor as tpe
status=0
enemy_x=0
enemy_y=0
enemy_can_touch_area=None
enemy_tmp=0
fighter_x=0
fighter_can_touch_area=None
beam_x=0
beam_y=0
beam_tmp=0
difference_x=0
difference_y=0
canmove=True
first=0
Anser=None

def move_enemy():
    global status,enemy_x,enemy_y,enemy_can_touch_area
    if status==0:
        enemy_x+=2
        canvas.move(Enemy,2,0)
        if enemy_x>=100:
            status=1
            canvas.move(Enemy,0,10)
            enemy_y+=10
            pass
    elif status==1:
        enemy_x-=2
        canvas.move(Enemy,-2,0)
        if enemy_x<=0:
            status=0
            canvas.move(Enemy,0,10)
            enemy_y+=10
            pass
    fighter_can_touch_area=canvas.bbox(Fighter)
    if fighter_can_touch_area[0]<=enemy_x and fighter_can_touch_area[2]>=enemy_x:
        print("Can touch x")
        if fighter_can_touch_area[1]<=enemy_y and fighter_can_touch_area[3]>=enemy_y:
            print("Can touch y")
            msb.showinfo("","ゲームオーバー")
            canvas.delete(Fighter)
            canvas.delete(Beam)
    canvas.after(30,move_enemy)

def move_fighter(Direction_of_movement):
    global fighter_x
    if Direction_of_movement=="Left":
        canvas.move(Fighter,-2,0)
        fighter_x-=2
    elif Direction_of_movement=="Right":
        fighter_x+=2
        canvas.move(Fighter,2,0)

def KeyEv(e):
    if e.char=="c":
        move_fighter(Direction_of_movement="Right")
    elif e.char=="z":
        move_fighter(Direction_of_movement="Left")
    elif e.char=="x":
        create_beam()
        

def create_beam():
    global difference_x,fighter_x,beam_x,beam_tmp,beam_y,difference_y,canmove,first
    beam_tmp=canvas.bbox(Beam)
    beam_x=beam_tmp[0]+4
    beam_y=beam_tmp[1]+16
    difference_x=fighter_x-beam_x
    difference_y=150-beam_y
    print("Beam_x : ",beam_x,"  Beam_y : ",beam_y,"  Fighter_x : ",fighter_x,"  Fighter_y : ",150,"  difference_x : ",difference_x,"  difference_y : ",difference_y)
    canvas.move(Beam,difference_x,difference_y-30)
    first+=1
    print(first)
    if first==1:
        move_beam()
    if beam_x>=0:
        canmove=False
    elif beam_x<=0:
        canmove=True
        first=0
    if canmove==True:
        move_beam()

def move_beam():
    global enemy_can_touch_area,enemy_tmp,beam_x,beam_y,beam_tmp
    canvas.move(Beam,0,-2)
    enemy_can_touch_area=canvas.bbox(Enemy)
    beam_tmp=canvas.bbox(Beam)
    beam_x=beam_tmp[0]+4
    beam_y=beam_tmp[1]+16
    if enemy_can_touch_area[0]<=beam_x and enemy_can_touch_area[2]>=beam_x:
        print("Can touch x")
        if enemy_can_touch_area[1]<=beam_y and enemy_can_touch_area[3]>=beam_y:
            print("Can touch y")
            msb.showinfo("","敵を撃退クリア")
            canvas.delete(Enemy)
    
    canvas.after(30,move_beam)
    

FilePath_BackGround=("./data/bg.png")
FilePath_Fighter=("./data/fighter.png")
FilePath_Enemy=("./data/ennemy.png")
FilePath_Beam=("./data/beam.png")

root=tk.Tk()
root.geometry("133x190")
root.title("ShootingGame-Rev.15")

canvas=tk.Canvas(bg="White",width=133,height=190)
canvas.pack()

Picture_BackGround=tk.PhotoImage(file=FilePath_BackGround)
Picture_Fighter=tk.PhotoImage(file=FilePath_Fighter)
Picture_Enemy=tk.PhotoImage(file=FilePath_Enemy)
Picture_Beam=tk.PhotoImage(file=FilePath_Beam)

BackGround=canvas.create_image(0,0,image=Picture_BackGround)
Fighter=canvas.create_image(0,150,image=Picture_Fighter)
Enemy=canvas.create_image(0,0,image=Picture_Enemy)
Beam=canvas.create_image(0,-50,image=Picture_Beam)

print("a")
root.bind("<Key>",KeyEv)
print("b")


move_enemy()
root.mainloop()
#----Update Info----#
#Create File(Clear Task : 1~2)          :2023.03.27
#Update File(Clear Task : Nome)         :2023.04.03
#Update File(Clear Task : 3~4)          :2023.04.06
#Update File(Clear Task : 5~8)          :2023.04.22

#----Crear Task----#
#条件1:Clear
#条件2:Clear
#条件3:Clear
#条件4:Clear
#条件5:Clear
#条件6:Clear
#条件7:Clear
#条件8:Clear
#条件9:Now
#------------------#